<?php
class WPBakeryShortCode_VC_Empty_space extends WPBakeryShortCode {
}